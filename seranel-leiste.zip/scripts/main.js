const ID = "seranel-leiste";
const MAX = 16;

// Stufen-Texte (für alle sichtbar)
function stufe(v) {
  if (v <= 0)  return { cls: "sl-ende-vhoruk", text: "Vhoruk hat Seranel erreicht" };
  if (v <= 4)  return { cls: "sl-schwach", text: "Seranel schwindet · Init 20: alle Spieler 2W8 psychisch" };
  if (v >= MAX) return { cls: "sl-ende-seranel", text: "Seranel wirft Vhoruk hinaus" };
  if (v >= 12) return { cls: "sl-stark", text: "Seranel erstarkt · Vorteil auf Rettungswürfe gegen Augenstrahlen" };
  return { cls: "", text: "" };
}

const wert = () => game.settings.get(ID, "wert");
const sichtbar = () => game.settings.get(ID, "sichtbar");

async function set(v) {
  if (!game.user.isGM) return;
  await game.settings.set(ID, "wert", Math.clamp(Math.round(v), 0, MAX));
}
const add = (d) => set(wert() + d);
async function setVis(b) { if (game.user.isGM) await game.settings.set(ID, "sichtbar", b); }
const toggle = () => setVis(!sichtbar());

let letzterWert = null;

function render(animiert = false) {
  const v = wert();
  const vis = sichtbar();
  const gm = game.user.isGM;
  let el = document.getElementById("seranel-leiste");

  if (!vis && !gm) { el?.remove(); return; }

  if (!el) {
    el = document.createElement("div");
    el.id = "seranel-leiste";
    el.innerHTML = `
      <div class="sl-kopf"><span class="sl-zier">✦</span><span class="sl-name">Seranel</span><span class="sl-zier">✦</span></div>
      <div class="sl-bahn">
        <div class="sl-glut"></div>
        <div class="sl-licht"><div class="sl-schimmer"></div></div>
        <div class="sl-marke" style="left:25%"></div>
        <div class="sl-marke sl-mitte" style="left:50%"></div>
        <div class="sl-marke" style="left:75%"></div>
        <div class="sl-stern">✦</div>
      </div>
      <div class="sl-text"></div>
      <div class="sl-gm">
        <button data-d="-4" title="Vhoruk siegt">−4</button>
        <button data-d="-1">−1</button>
        <span class="sl-zahl"></span>
        <button data-d="1">+1</button>
        <button data-d="4" title="Spieler siegen">+4</button>
        <button data-vis title="Für Spieler ein-/ausblenden"><i class="fas fa-eye"></i></button>
      </div>`;
    document.body.appendChild(el);
    el.querySelectorAll(".sl-gm button[data-d]").forEach(b =>
      b.addEventListener("click", () => add(Number(b.dataset.d))));
    el.querySelector(".sl-gm button[data-vis]").addEventListener("click", toggle);
  }

  const p = (v / MAX) * 100;
  const s = stufe(v);
  el.className = [s.cls, gm ? "sl-ist-gm" : "", vis ? "" : "sl-verborgen"].join(" ").trim();
  el.querySelector(".sl-licht").style.width = `${p}%`;
  el.querySelector(".sl-stern").style.left = `${p}%`;
  el.querySelector(".sl-text").textContent = s.text;
  el.querySelector(".sl-zahl").textContent = `${v} / ${MAX}`;
  el.querySelector(".sl-gm button[data-vis] i").className = vis ? "fas fa-eye" : "fas fa-eye-slash";

  if (animiert && letzterWert !== null && letzterWert !== v) {
    const k = v > letzterWert ? "sl-puls-hell" : "sl-puls-dunkel";
    el.classList.remove("sl-puls-hell", "sl-puls-dunkel");
    void el.offsetWidth;
    el.classList.add(k);
  }
  letzterWert = v;
}

Hooks.once("init", () => {
  game.settings.register(ID, "wert", {
    scope: "world", config: false, type: Number, default: 8,
    onChange: () => render(true)
  });
  game.settings.register(ID, "sichtbar", {
    scope: "world", config: false, type: Boolean, default: false,
    onChange: () => render()
  });
});

Hooks.once("ready", () => {
  globalThis.SeranelLeiste = { set, add, toggle, zeigen: () => setVis(true), verbergen: () => setVis(false), wert };
  render();
});
