# Seranel-Leiste (Foundry v12)

## Installation
1. Ordner `seranel-leiste` nach `Data/modules/` kopieren
2. Foundry neu laden → Welt → Module verwalten → **Seranel-Leiste** aktivieren

## Bedienung (nur SL)
- Die Leiste startet **für Spieler verborgen**, du siehst sie halbtransparent
- Auge-Knopf: für alle ein-/ausblenden
- **−4 / +4:** Sieg Vhoruk / Sieg Spieler · −1 / +1 zum Korrigieren
- Startwert 8, Bereich 0–16, Stand bleibt nach Neuladen erhalten

## Makros (optional)
```js
SeranelLeiste.add(4)     // Spieler siegen
SeranelLeiste.add(-4)    // Vhoruk siegt
SeranelLeiste.set(8)     // Reset für neuen Kampf
SeranelLeiste.toggle()   // ein-/ausblenden
```

## Anpassen
- Position: in `styles/leiste.css` bei `#seranel-leiste` den Wert `top: 64px` ändern
